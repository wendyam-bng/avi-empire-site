
document.getElementById('chat').innerHTML = `
  <div style="background:#fff;padding:1rem;border-radius:1rem;box-shadow:0 0 10px #ccc">
    <strong>Assistant AVI :</strong>
    <p>Bonjour ! Comment puis-je vous aider aujourd'hui ?</p>
  </div>
`;
